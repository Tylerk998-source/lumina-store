# Lumina — Dropshipping Store (Expanded)

Clean, professional dropshipping storefront + full admin backend.

## What's New

### Storefront
- **12 researched high-margin products** chosen for fast conversion potential (Beauty, Home, Wellness, Tech)
- **Multi-image product pages** — click any product to see a gallery of photos + detailed description, features, and specs
- Clean mobile-first design, category filters, search, cart, checkout simulation, newsletter, account signup

### Admin (Shopify-style)
- Professional sidebar navigation
- Home dashboard with revenue, orders, customers, subscribers + charts
- Orders list with fulfillment status
- Products catalog (dropship infinite stock)
- Customers + email subscribers
- Analytics (conversion, AOV, traffic, top products)
- Marketing (subscriber list + demo campaign sender)
- Settings (store info, providers, payments)

## How to use
1. Open `index.html` in a browser
2. Browse products → click one to see multiple photos and full details
3. Add to cart → checkout (creates a real order in localStorage)
4. Open `admin.html` (or click Admin) → sign in with the pre-filled credentials
5. Your orders, stats, and subscribers appear in the dashboard

All data lives in the browser's localStorage.

## Product selection logic (Nov 2026 research)
Products were chosen for:
- Strong demand / trending signals
- High perceived value vs cost (good retail margins)
- Visual / demo-friendly (great for TikTok / Reels)
- Impulse-friendly price range ($22–$79)
- Light shipping + problem-solving or aesthetic appeal

Top picks include LED Face Mask, Posture Corrector, Heatless Curling Set, Candle Warmer, Spin Scrubber, Sunset Lamp, etc.

## Going live
This is a frontend prototype. For a real business connect:
- Shopify / WooCommerce / custom
- Stripe / PayPal
- Spocket, Zendrop, CJDropshipping, or Printful
- Klaviyo or Mailchimp
